import numpy as np
import os as os
import pandas as pd
import matplotlib.pyplot as plt
from astropy.io import fits
from astropy.wcs import WCS

from cosmology import LookbackTime, SolveForRedshift



catalog_to_use = 'COSMOS_DR2'

if catalog_to_use == 'UDS':
    path_cat = './simstack_catalogs/uds8.csv'
elif catalog_to_use == 'COSMOS_DR1':
    path_cat = './simstack_catalogs/UVISTA/DR1/UVISTA_DR1.csv'
elif catalog_to_use == 'COSMOS_DR2':
    path_cat = './simstack_catalogs/UVISTA/DR2/UVISTA_DR2_master_v2.1_USE.csv'
else:
    raise NameError("'"+str(catalog_to_use)+"'"+Error_Msg('is not a valid catalog name.'))



class TwoDBinning():
    
    def __init__(self, N_Abins, N_Bbins, z_scale, N_thres, sf_flag, map_selected):
        self.N_Abins = N_Abins
        self.N_Bbins = N_Bbins
        self.N_Alines = self.N_Abins - 1
        self.N_Blines = self.N_Bbins - 1
        self.z_scale = z_scale
        self.N_thres = N_thres
        self.sf_flag = sf_flag
        self.map_selected = map_selected
        self.iwv = 9
    
    def make_data(self):
        
        if catalog_to_use == 'UDS':
            col_to_read = ['RA','DEC','z_peak','mass','dead']
        elif catalog_to_use == 'COSMOS_DR2':
            col_to_read = ['ID','ra','dec','z_peak','lmass','rf_U_V','rf_V_J']

        df_cat_in = pd.read_csv(path_cat,usecols=col_to_read)
        header_list = list(df_cat_in.columns.values)

        cat_in = df_cat_in.as_matrix(columns=df_cat_in.columns)
        n_sources = cat_in.shape[0]; n_params = cat_in.shape[1]
        print 'Size Read-In: ', cat_in.shape
        # Discard rows w/o M* and/or z_peak values
        ind_valid = np.ones((n_sources,), dtype=np.int)
        for j in range(2,n_params):
            ind_valid = ind_valid-np.isnan(cat_in[:,j])
        # Discard rows with faulty M* (i.e. M* not in [5.0,14.0])
        ind_valid = ind_valid - ((cat_in[:,4]<5.0) + (cat_in[:,4]>14.0))
        # Discard rows with dead galaxies
        if catalog_to_use == 'UDS':
            ind_valid = ind_valid - (cat_in[:,4]==1.0)
        # Get the indices of filtered rows 
        ind_valid = np.where(ind_valid)[0]

        # Update the size of the input catalog
        cat_in = cat_in[ind_valid,:]
        print 'Size Filtered: ', cat_in.shape
        n_sources = cat_in.shape[0]; n_params = cat_in.shape[1]

        ### Separate the ID, RA, DEC, mass and redshift columns ###
        ID_index = header_list.index(col_to_read[0])
        RA_index = header_list.index(col_to_read[1])
        DEC_index = header_list.index(col_to_read[2])
        z_index = header_list.index(col_to_read[3])
        m_index = header_list.index(col_to_read[4])
        
        if catalog_to_use == 'UDS':
            sf_index = header_list.index('dead')
        elif catalog_to_use == 'COSMOS_DR2':
            uv_index = header_list.index('rf_U_V')
            vj_index = header_list.index('rf_V_J')
        
        ID_column = cat_in[:,ID_index]
        RA_column = cat_in[:,RA_index]
        DEC_column = cat_in[:,DEC_index]
        m_column = cat_in[:,m_index]
        z_column = cat_in[:,z_index]
        if catalog_to_use == 'UDS':
            sf_column = cat_in[:,sf_index]
        elif catalog_to_use == 'COSMOS_DR2':
            uv_column = cat_in[:,uv_index]
            vj_column = cat_in[:,vj_index]
            
            sf_column = np.zeros(RA_column.shape)
            sf_column[np.where((uv_column>1.3)&
                               (vj_column<1.5)&
                               (uv_column>0.88*vj_column+0.69)&
                               (z_column<1)
                              )[0]] = 1
            sf_column[np.where((uv_column>1.3)&
                               (vj_column<1.5)&
                               (uv_column>0.88*vj_column+0.59)&
                               (z_column>=1.))[0]] = 1
            
            print 'Number of dead galaxies: ', np.where(sf_column==1)[0].shape[0]
            
            ID_column = ID_column[np.where(sf_column==self.sf_flag)[0]]
            RA_column = RA_column[np.where(sf_column==self.sf_flag)[0]]
            DEC_column = DEC_column[np.where(sf_column==self.sf_flag)[0]]
            m_column = m_column[np.where(sf_column==self.sf_flag)[0]]
            z_column = z_column[np.where(sf_column==self.sf_flag)[0]]
        
        if self.map_selected == True:

            mask_path = './masks/'
            masks = [
                     mask_path+'mips_24_mask.fits',
                     mask_path+'spitzer_70_mask.fits',
                     mask_path+'pacs_100_mask.fits',
                     mask_path+'pacs_160_mask.fits',
                     mask_path+'spire_250_mask.fits',
                     mask_path+'spire_350_mask.fits',
                     mask_path+'scuba_450_mask.fits',
                     mask_path+'spire_500_mask.fits',
                     mask_path+'scuba_850_mask.fits',
                     mask_path+'aztec_6.0_arcsec_1100_mask.fits'
                     ]
            print '\n# ---------- Mask Used ---------- #'
            print masks[self.iwv]
            print '# ------------------------------- #\n'
            
            w = WCS(masks[self.iwv])
            mmap, mhd = fits.getdata(masks[self.iwv], 0, header = True)
            cms = mmap.shape

            ty, tx = w.wcs_world2pix(RA_column, DEC_column, 0, ra_dec_order=True) 
            ind_keep = np.where((tx >= 0) & (np.round(tx) < cms[0]) & (ty >= 0) & (np.round(ty) < cms[1]))
            real_x=np.round(tx[ind_keep[0]]).astype(int)
            real_y=np.round(ty[ind_keep[0]]).astype(int)

            ival = np.array([mmap[real_x[i],real_y[i]] for i in range(np.size(real_x))])
            i_map_selected = np.where(ival!=0)[0]
            i_map_selected = ind_keep[0][i_map_selected]
            
            ID_column = ID_column[i_map_selected]
            RA_column = RA_column[i_map_selected]
            DEC_column = DEC_column[i_map_selected]
            m_column = m_column[i_map_selected]
            z_column = z_column[i_map_selected]
        
        # Read in columns
        A_arr = m_column
        B_arr = z_column

        data = np.hstack((m_column[None].T, z_column[None].T, RA_column[None].T, DEC_column[None].T, ID_column[None].T))
        
        # Start with uniform bins
        if self.N_Abins==3:
            A_lp_0 = np.array([8.5,10.0,11.0,13.0])
        elif self.N_Abins==5:
            A_lp_0 = np.array([8.5,9.5,10.0,10.5,11.0,13.0])
        else:
            A_lp_0 = np.linspace(8.5,12.5,self.N_Abins+1)
        
        if self.z_scale == 'redshift':
            B_lp_0 = np.linspace(0.,5.,self.N_Bbins+1)
        elif self.z_scale == 'lookback_time':
            B_lp_0 = SolveForRedshift(np.linspace(LookbackTime(0.),LookbackTime(5.),self.N_Bbins+1))
        
        dic0 = {'A_bins': (self.N_Abins,A_lp_0), 'B_bins': (self.N_Bbins,B_lp_0)}

        dic = dic0
        A_lp_i = np.copy(dic0['A_bins'][1])
        B_lp_i = np.copy(dic0['B_bins'][1])
        #C_lp_i = np.copy(dic0['C_bins'][1])

        # Initialize data cube
        data_cube = np.zeros((self.N_Abins, self.N_Bbins))
        
        # Fill the data cube with the default binning
        for iB in range(self.N_Bbins):
            ind = np.where((data[:,1]>=B_lp_0[iB]) & (data[:,1]<B_lp_0[iB+1]))[0]
            data_cube[:,iB] = np.histogram(data[ind,0], bins=A_lp_0)[0]
                
        return [data, data_cube, dic0]

    






class AdaptBinning(TwoDBinning):
    
    def __init__(self, N_Abins=5, N_Bbins=8, z_scale='lookback_time', N_thres=10, sf_flag=1, map_selected=False, N_iter=1000):
        
        TwoDBinning.__init__(self, N_Abins, N_Bbins, z_scale, N_thres, sf_flag, map_selected)
        
        self.N_iter = N_iter
        self.expo_coeff = [0.01,0.1,1.]
        self.wavelength = [24,70,100,160,250,350,450,500,850,1100]
    
    
    
    def Plot_Grid(self, X_Name, Y_Name, Z, dic, figname):
        # Plot the binning in a 2D grid 
        X = dic[X_Name][1]
        Y = dic[Y_Name][1]

        # Get log number counts
        log10_Z = np.log10(Z)
        barvs = np.linspace(0.0,4.0,5)

        text_xs = (X[0:-1]+X[1::])/2.
        text_ys = (Y[0:-1]+Y[1::])/2.
        plt.figure(figsize=(16,6))
        plt.pcolor(X, Y, log10_Z, cmap='coolwarm', \
                   vmin=barvs[0], vmax=barvs[-1])
        for i in range(0,text_xs.shape[0]):
            for j in range(0,text_ys.shape[0]):
                plt.text(text_xs[i],text_ys[j],str(int(Z[j,i])),ha='center',fontsize=12)
        XT = np.zeros(np.size(X))
        for i in range(np.size(X)):
            XT[i] = LookbackTime(X[i])
            #print 'time =', XT[i]
        plt.xticks(X, np.round(X,2), fontsize=12)
        plt.yticks(Y, np.round(Y,2), fontsize=12)
        plt.xlabel(X_Name, fontsize=15)
        plt.ylabel(Y_Name, fontsize=15)
        plt.xlim([min(X),max(X)])
        plt.ylim([min(Y),max(Y)])
        cb = plt.colorbar(ticks=barvs)
        cb.ax.tick_params(labelsize=12)
        cb.set_label('Log Number Counts', fontsize=15)
        plt.grid(True)
        plt.savefig(figname, dpi=200)

        return 0
    
    
    
    def P_func_L(self, l_name, l_index, data_cube, flag):
        # ----- Penalty function on the left ----- #
        
        if l_name == 'A_bins':
            temp = data_cube[l_index-1,:]
        elif l_name == 'B_bins':
            temp = data_cube[:,l_index-1]

        if min(temp)>1.*self.N_thres:
            coeff = self.expo_coeff[flag]
            #expo = coeff*self.N_thres/(self.N_thres-min(data_cube.flatten()))
            expo = coeff*(self.N_thres-min(temp))
            #temp = -np.sum((np.minimum(temp,min(temp))-self.N_thres)**expo)
            temp = -np.sum((np.maximum(temp,min(temp))-self.N_thres)**expo)
            #temp = 1.0
        else:
            temp = np.maximum((self.N_thres+1 - temp),0.0)**100
            temp = np.sum(temp)

        return temp
    
    
    
    def P_func_R(self, l_name, l_index, data_cube, flag):
        # ----- Penalty function on the right ----- #
        
        if l_name == 'A_bins':
            temp = data_cube[l_index,:]
        elif l_name == 'B_bins':
            temp = data_cube[:,l_index]

        if min(temp)>1.*self.N_thres:
            coeff = self.expo_coeff[flag]
            #expo = coeff*self.N_thres/(self.N_thres-min(data_cube.flatten()))
            expo = coeff*(self.N_thres-min(temp))
            #temp = -np.sum((np.minimum(temp,min(temp))-self.N_thres)**expo)
            temp = -np.sum((np.maximum(temp,min(temp))-self.N_thres)**expo)
            #temp = 1.0
        else:
            temp = np.maximum((self.N_thres+1 - temp),0.0)**100
            temp = np.sum(temp)

        return temp
    
    
    
    def P_func_diff(self, l_name, l_index, data_cube, flag):
        return self.P_func_L(l_name, l_index, data_cube, flag) - self.P_func_R(l_name, l_index, data_cube, flag)
    
    
    
    def Run_Adapt(self, print_to_files=False):
        
        flag_counter = 0
        while flag_counter < np.size(self.expo_coeff):
                        
            [data, data_cube, dic] = TwoDBinning(self.N_Abins, self.N_Bbins, self.z_scale, self.N_thres, \
                                                 self.sf_flag, self.map_selected).make_data()
            
            if flag_counter == 0:
            	# print 'Initial Gird =\n', data_cube.T
                self.Plot_Grid('B_bins', 'A_bins', data_cube, dic, 'Initial_Grid.png')

            N_bins_tot = self.N_Alines+self.N_Blines#+self.N_Clines
            bins_list = []
            for iA in range(self.N_Abins-1):
                bins_list.append('A_bins')
            for iB in range(self.N_Bbins-1):
                bins_list.append('B_bins')
            
            
            i_counter = 0
            while (min(data_cube.flatten())<self.N_thres) and i_counter<self.N_iter:

                A_lp_i = dic['A_bins'][1]
                B_lp_i = dic['B_bins'][1]
                flag = flag_counter

                # Save values of penalties to a list
                P_func_list = np.empty(N_bins_tot)
                P_funcL_list = np.empty(N_bins_tot)
                P_funcR_list = np.empty(N_bins_tot)
                for i in range(N_bins_tot):
                    if i<self.N_Alines:
                        P_func_list[i] = self.P_func_diff(bins_list[i], i+1, data_cube, flag)
                        P_funcL_list[i] = self.P_func_L(bins_list[i], i+1, data_cube, flag)
                        P_funcR_list[i] = self.P_func_R(bins_list[i], i+1, data_cube, flag)
                    elif i<self.N_Alines+self.N_Blines:
                        P_func_list[i] = self.P_func_diff(bins_list[i], i-self.N_Alines+1, data_cube, flag)
                        P_funcL_list[i] = self.P_func_L(bins_list[i], i-self.N_Alines+1, data_cube, flag)
                        P_funcR_list[i] = self.P_func_R(bins_list[i], i-self.N_Alines+1, data_cube, flag)



                # Move the boarder with the largest penalty
                i_move = np.argmax(abs(P_func_list))

                if i_move<self.N_Abins-1:
                    if P_func_list[i_move]>0.0:
                        A_lp_i[i_move+1] += (A_lp_i[i_move+2] - A_lp_i[i_move+1])*0.1
                        # Add averaging procedure here
                        
                    elif P_func_list[i_move]<0.0:
                        A_lp_i[i_move+1] += (A_lp_i[i_move] - A_lp_i[i_move+1])*0.1
                        # Add averaging procedure here

                elif i_move<self.N_Abins-1+self.N_Bbins-1:
                    if P_func_list[i_move]>0.0:
                        B_lp_i[i_move-self.N_Alines+1] += (B_lp_i[i_move-self.N_Alines+2] - \
                                                           B_lp_i[i_move-self.N_Alines+1])*0.1
                        # Add averaging procedures here
                        B_lp_i[i_move-self.N_Alines+1::] = SolveForRedshift(np.linspace(LookbackTime(B_lp_i[i_move-self.N_Alines+1]),\
                                                                                        LookbackTime(5.),\
                                                                                        B_lp_i[i_move-self.N_Alines+1::].shape[0]))
                        B_lp_i[0:i_move-self.N_Alines+2] = SolveForRedshift(np.linspace(LookbackTime(0.),\
                                                                                        LookbackTime(B_lp_i[i_move-self.N_Alines+1]),\
                                                                                        B_lp_i[0:i_move-self.N_Alines+2].shape[0]))
                        
                    elif P_func_list[i_move]<0.0:
                        B_lp_i[i_move-self.N_Alines+1] += (B_lp_i[i_move-self.N_Alines] - \
                                                           B_lp_i[i_move-self.N_Alines+1])*0.1
                        # Add averaging procedure here
                        B_lp_i[i_move-self.N_Alines+1::] = SolveForRedshift(np.linspace(LookbackTime(B_lp_i[i_move-self.N_Alines+1]),\
                                                                                        LookbackTime(5.),\
                                                                                        B_lp_i[i_move-self.N_Alines+1::].shape[0]))
                        B_lp_i[0:i_move-self.N_Alines+2] = SolveForRedshift(np.linspace(LookbackTime(0.),\
                                                                                        LookbackTime(B_lp_i[i_move-self.N_Alines+1]),\
                                                                                        B_lp_i[0:i_move-self.N_Alines+2].shape[0]))
                        

                dic = {'A_bins': (self.N_Abins,A_lp_i), 'B_bins': (self.N_Bbins,B_lp_i)}


                # Initialize data cube
                data_cube = np.zeros((self.N_Abins, self.N_Bbins))

                # Fill the data cube with the default binning
                for iB in range(self.N_Bbins):
                    ind = np.where((data[:,1]>=B_lp_i[iB]) & (data[:,1]<B_lp_i[iB+1]))[0]
                    data_cube[:,iB] = np.histogram(data[ind,0], bins=A_lp_i)[0]
                
                i_counter += 1
                
                #self.Plot_Grid('B_bins', 'A_bins', data_cube, dic)
                
                print 'NSources_min = %d\n' % min(data_cube.flatten())
			
			
			
			
			
			
            if min(data_cube.flatten())>=self.N_thres:
                
                pop = ['sf','qt']
                wavelength=[24,70,100,160,250,350,450,500,850,1100]
                #print 'Final Gird =\n', data_cube.T
                
                # Write ngal matrix to file
                if self.map_selected==True:
                    np.savetxt('./ngal_matrices/ngal_%s_%d.dat'%(pop[self.sf_flag],wavelength[self.iwv]),
                               data_cube.T, fmt='%.1f', delimiter='\t')
                
                self.Plot_Grid('B_bins', 'A_bins', data_cube, dic, 'Final_Grid.png')
                
                #if (flag_counter==0) & (i_counter==0):
                #    print 'YES!'
                #    A_lp_i = dic['A_bins'][1]
                #    B_lp_i = dic['B_bins'][1]
                
                if print_to_files == True:
                    for i in range(0,A_lp_i.shape[0]-1,1):
                        for j in range(0,B_lp_i.shape[0]-1,1):
                            
                            # Get the indices of the sources in this bin
                            ind = np.where((data[:,0]>=A_lp_i[i])&(data[:,0]<A_lp_i[i+1])&
                                           (data[:,1]>=B_lp_i[j])&(data[:,1]<B_lp_i[j+1]))[0]

                            RAs = data[ind,2]
                            DECs = data[ind,3]
                            IDs = data[ind,4]
                            ms = data[ind,0]
                            zs = data[ind,1]

                            mlabel = "m[%.2f,%.2f]" % (round(A_lp_i[i],2),round(A_lp_i[i+1],2))
                            zlabel = "z[%.2f,%.2f]" % (round(B_lp_i[j],2),round(B_lp_i[j+1],2))
                            fn_ij = "cat_" + mlabel + "_" + zlabel
                            if self.sf_flag == 0:
                                path_ij = './binned_cats/%d_masked_'%self.wavelength[self.iwv] + fn_ij + '_sf.csv'
                            else:
                                path_ij = './binned_cats/%d_masked_'%self.wavelength[self.iwv] + fn_ij + '_qt.csv'
                            binsize_ij = ind.shape[0]

                            data_to_print = np.hstack((IDs[None].T, RAs[None].T, DECs[None].T, ms[None].T, zs[None].T))

                            np.savetxt(path_ij, data_to_print, fmt=['%d', '%.6f','%.6f', '%.6f','%.6f'], delimiter=',', \
                                       header='ID\tRA\tDEC\tStellarMass\tRedshift')

                            print "Assigned %d sources to the %d th binned catalog." % (binsize_ij,i*self.N_Bbins+j+1)
                else:
                    pass
                
                self.m_nodes_opt = np.around(A_lp_i, decimals=2)
                self.z_nodes_opt = np.around(B_lp_i, decimals=2)
                
                print '---------- Apdative Binning Done ----------'
                
                return 0
            
            else:
                print 'Maximum number of iteractions (%d) reached!' % (i_counter)
                flag_counter += 1
        
        
        self.m_nodes_opt = np.nan
        self.z_nodes_opt = np.nan
        
        raise RuntimeError('Can\'t find optimized binning. Try reducing N_thres or the number of bins!')
        
        return 0




# Run adaptive binning

sample = AdaptBinning(N_Abins=5, N_Bbins=8, N_thres=20, sf_flag=0, map_selected=True)

sample.Run_Adapt()