import numpy as np
from scipy.integrate import quad
import scipy.optimize as optimize

### ====================   Cosmology   ==================== ###

km_per_pc = 3.08568e13
km_per_mpc = km_per_pc*1e6
sec_per_yr = 3.15576E7
sec_per_Gyr = 3.15576E16
hubble_0 = 0.6774
H_0 = hubble_0 * 100 / km_per_mpc
Omega_m_0 = 0.3089
Omega_l_0 = 0.6911

def EvolutionFunction(z):
    return np.sqrt(Omega_m_0 * (1.0 + z)**3  + Omega_l_0)

def HubbleParameter(z):
    return H_0 * EvolutionFunction(z)

def LookbackTime(z_f, z_i=0.0):
    ''' Returns the lookback time in [Gyr], note that z_i<z_f '''
    integrand = lambda z: 1. / (1. + z) / EvolutionFunction(z)
    return quad(integrand, z_i, z_f)[0] / HubbleParameter(z_i) / sec_per_Gyr

def SolveForRedshift(t):
    ''' Take a lookback time in [Gyr] and return the corresponding redshift '''
    f_to_solve = lambda z_f: t - LookbackTime(z_f)
    if f_to_solve(0.) * f_to_solve(10.) > 0.:
        raise ValueError(Error_Msg('ImproperBinSize'))
    else:
        root = optimize.brenth(f_to_solve, 0., 10.)
        return root
SolveForRedshift = np.vectorize(SolveForRedshift)